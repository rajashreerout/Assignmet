package com.smartshop.user.exception;

public class Exception {

}
