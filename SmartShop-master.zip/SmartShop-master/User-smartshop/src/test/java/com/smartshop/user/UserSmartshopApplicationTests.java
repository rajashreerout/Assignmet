package com.smartshop.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserSmartshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
