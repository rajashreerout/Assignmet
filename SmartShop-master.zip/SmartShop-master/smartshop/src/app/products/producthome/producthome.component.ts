import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-producthome',
  templateUrl: './producthome.component.html',
  styleUrls: ['./producthome.component.css']
})
export class ProducthomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
