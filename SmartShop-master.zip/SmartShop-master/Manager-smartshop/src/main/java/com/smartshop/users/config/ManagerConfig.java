package com.smartshop.users.config;


//@Configuration
//@EnableWebMvc

public class ManagerConfig {
	
	

}
