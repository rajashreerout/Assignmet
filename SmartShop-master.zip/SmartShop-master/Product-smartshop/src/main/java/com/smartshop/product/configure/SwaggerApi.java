package com.smartshop.product.configure;

public class SwaggerApi {

}
